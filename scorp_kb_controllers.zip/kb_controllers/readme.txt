Keyboard Controller Dumps:

Dump file naming format:
<ID>_<TOOL>_<CODE>.BIN

Image file naming format:
<ID>_img.jpg

ID - the Controller number (1,2,3...)
TOOL - either JK(JetKey) or AK(AmiKey)
CODE - the return code of the tool _ for "unknown" or "not found"

The controllers 1-4 were test on a 286 mainboard:
https://www.ultimateretro.net/de/motherboards/6763

The controllers 5-7 were tested on a 386 mainboard:
https://www.ultimateretro.net/de/motherboards/5397
